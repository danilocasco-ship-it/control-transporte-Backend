﻿using Application.Configuration;
using Application.SQL.Login_pre.DTO;
using Application.SQL.Login_pre.Interface;
using Application.SQL.Login_pre.Parameter;
using Infrastructure.DataConnection.ConnectionSQL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Application.SQL.Login_pre.service
{
    public class Login_Service : ILogin_Services
    {
        private readonly IDbExecutor _dbExecutor;
        private readonly IDataMapper _dbMapper;

        public Login_Service(IDbExecutor dbExecutor, IDataMapper dbMapper)
        {
            _dbExecutor = dbExecutor;
            _dbMapper = dbMapper;
        }

        public Login_DTO Login(Parameter_Login parameter, string db)
        {
            DataTable dt = _dbExecutor.ExecuteStoredProcedure("VERIFICAR_AUTENTICACION", new
            {

                codempresa = parameter.codempresa,
                codusuario = parameter.codusuario,
                clave = parameter.clave

            }, true, db);

            Login_DTO result = _dbMapper.MapDataTableToObject<Login_DTO>(dt);
            return result;
        }

        //public Response_PasswordDTO PasswordChange(Parameter_PasswordDTO parameter, string db)

            public Response_PasswordDTO PasswordChanger(Parameter_PasswordDTO parameter, string db)

        {
            DataTable dt = _dbExecutor.ExecuteStoredProcedure("CENTRIES_CAMBIO_CONTRASENA", new
            {
                id = parameter.id,
                codusuario = parameter.codusuario,
                clave = parameter.clave
            }, true, db);

            Response_PasswordDTO result = _dbMapper.MapDataTableToObject<Response_PasswordDTO>(dt);
            return result;
        }
        public List<Permisos_DTO> permisos(int Id, string db)
        {
            // Aquí va tu lógica para obtener los permisos desde la base de datos
            // Por ahora puedes dejar un return vacío para que compile
            return new List<Permisos_DTO>();
        }

    }
}

